package com.example.ibragimov_30_01;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import static java.lang.Math.*;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    TextView viv1, viv2, viv3;
    EditText radius1,radius2;
    int vvr1, vvr2;
    double vivp1, vivp2, vivp3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viv1 = findViewById(R.id.plo1);
        viv2 = findViewById(R.id.plo2);
        viv3 = findViewById(R.id.plo3);
        radius1 = findViewById(R.id.rad1);
        radius2 = findViewById(R.id.rad2);
    }
    public void vic (View view){
        vvr1=Integer.parseInt(radius1.getText().toString());
        vvr2=Integer.parseInt(radius2.getText().toString());
     vivp1= PI*pow(vvr1,2);
     vivp2= PI*pow(vvr2,2);
     vivp3= vivp1-vivp2;

     viv1.setText("площадь первого:"+vivp1);
     viv2.setText("площадь второго:"+vivp2);
     viv3.setText("площадь третьего:"+vivp3);

    }
    public void OnClick2 (View view){
        Intent intent = new Intent(this, Zad2.class);
        startActivity(intent);
    }
    public void OnClick3 (View view){
        Intent intent = new Intent(this, Zad2.class);
        startActivity(intent);
    }
}