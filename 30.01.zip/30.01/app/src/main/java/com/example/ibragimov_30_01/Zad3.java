package com.example.ibragimov_30_01;

import static java.lang.Math.pow;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Zad3 extends AppCompatActivity {
    TextView viv1;
    EditText radius1, radius2;
    int vvr1;
    double vivY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zad3);
        viv1 = findViewById(R.id.plo1);
        radius1 = findViewById(R.id.rad1);
    }

    public void vic(View viev) {
        vvr1 = Integer.parseInt(radius1.getText().toString());
        int b = 1;
        String s="";
        b = (int) (b * pow(vvr1, 2));
        s=s+"A^2="+b;
        b = (int) (b * vvr1);
        s=s+"; \nA^3="+b;
        b = (int) (b * pow(vvr1, 2));
        s=s+"; \nA^5="+b;
        b = (int) (b * pow(vvr1, 5));
        s=s+"; \nA^10="+b;
        b = (int) (b * pow(vvr1, 5));
        s=s+"; \nA^15="+b;
        viv1.setText(s);
    }

    public void OnClick1(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void OnClick2(View view) {
        Intent intent = new Intent(this, Zad2.class);
        startActivity(intent);
    }
}