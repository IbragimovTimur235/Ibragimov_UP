package com.example.ibragimov_30_01;

import static java.lang.Math.*;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Zad2 extends AppCompatActivity {
    TextView viv1;
    EditText radius1;
    int vvr1;
    double vivY;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zad2);
        viv1 = findViewById(R.id.plo1);
        radius1 = findViewById(R.id.rad1);
    }
    public void vic (View viev){
        vvr1=Integer.parseInt(radius1.getText().toString());
        vivY=4*pow(vvr1-3,6) - 7*pow(vvr1-3,6)+ 2;
        viv1.setText("Y="+vivY);
    }
    public void OnClick1 (View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void OnClick3 (View view){
        Intent intent = new Intent(this, Zad3.class);
        startActivity(intent);
    }
}